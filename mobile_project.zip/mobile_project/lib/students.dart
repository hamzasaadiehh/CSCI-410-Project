class Student {
  const Student({required this.id, required this.name, required this.grade});

  final int id;
  final String name;
  final int grade;
}